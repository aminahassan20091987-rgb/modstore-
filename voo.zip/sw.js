/* ============================================================
   Service Worker — EarnMoney FBU
   Mode : cache offline + notifications push (démo)
   ============================================================ */

const CACHE_NAME = 'earnmoney-fbu-v1';
const CACHE_URLS = [
  './',
  './home.html',
  './wallet.html',
  './profile.html',
  './tasks.html',
  './manifest.json'
];

// ✅ Installation : on met en cache les fichiers principaux
self.addEventListener('install', (event) => {
  console.log('[SW] Installation...');
  event.waitUntil(
    caches.open(CACHE_NAME)
    .then((cache) => {
      console.log('[SW] Mise en cache des fichiers principaux');
      return cache.addAll(CACHE_URLS).catch((err) => {
        console.warn('[SW] Certains fichiers n\'ont pas pu être mis en cache :', err);
      });
    })
    .then(() => self.skipWaiting())
  );
});

// ✅ Activation : on nettoie les anciens caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activation...');
  event.waitUntil(
    caches.keys()
    .then((keys) => {
      return Promise.all(
        keys
        .filter((key) => key !== CACHE_NAME)
        .map((key) => {
          console.log('[SW] Suppression ancien cache :', key);
          return caches.delete(key);
        })
      );
    })
    .then(() => self.clients.claim())
  );
});

// ✅ Fetch : stratégie "cache first, network fallback"
self.addEventListener('fetch', (event) => {
  // On ignore les requêtes non-GET et les URLs externes
  if (event.request.method !== 'GET') return;
  
  const url = new URL(event.request.url);
  // On ne cache que les ressources de même origine
  if (url.origin !== location.origin) return;
  
  event.respondWith(
    caches.match(event.request)
    .then((cached) => {
      if (cached) {
        return cached;
      }
      
      return fetch(event.request)
        .then((response) => {
          // Ne pas cacher les erreurs
          if (!response || response.status !== 200 || response.type === 'opaque') {
            return response;
          }
          
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
          
          return response;
        })
        .catch(() => {
          // Si réseau échoue → page d'accueil en cache
          if (event.request.mode === 'navigate') {
            return caches.match('./home.html');
          }
          return new Response('Hors ligne', { status: 503 });
        });
    })
  );
});

// ✅ Notifications push
self.addEventListener('push', (event) => {
  console.log('[SW] Push reçu');
  
  let data = {
    title: 'EarnMoney FBU',
    body: 'Nouvelle notification',
    icon: './assets/img/icon-192.png',
    badge: './assets/img/icon-192.png',
    tag: 'fbu-notif',
    data: { url: './home.html' }
  };
  
  if (event.data) {
    try {
      const payload = event.data.json();
      data = { ...data, ...payload };
    } catch (e) {
      data.body = event.data.text();
    }
  }
  
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon,
      badge: data.badge,
      tag: data.tag,
      data: data.data,
      vibrate: [200, 100, 200],
      requireInteraction: false
    })
  );
});

// ✅ Clic sur la notification
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification cliquée');
  event.notification.close();
  
  const targetUrl = event.notification.data?.url || './home.html';
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
    .then((clientList) => {
      // Si un onglet est déjà ouvert → focus
      for (const client of clientList) {
        if (client.url.includes(location.origin) && 'focus' in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      // Sinon ouvrir un nouvel onglet
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

// ✅ Message depuis la page (pour tester les notifs locales)
self.addEventListener('message', (event) => {
  console.log('[SW] Message reçu :', event.data);
  
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    const { title, body, url } = event.data;
    self.registration.showNotification(title || 'EarnMoney FBU', {
      body: body || 'Notification de test',
      icon: './assets/img/icon-192.png',
      badge: './assets/img/icon-192.png',
      data: { url: url || './home.html' },
      vibrate: [200, 100, 200]
    });
  }
});

// ✅ Sync en arrière-plan (optionnel)
self.addEventListener('sync', (event) => {
  console.log('[SW] Sync :', event.tag);
  if (event.tag === 'sync-earnings') {
    event.waitUntil(
      // Logique de synchronisation
      Promise.resolve()
    );
  }
});

console.log('[SW] Service Worker chargé');