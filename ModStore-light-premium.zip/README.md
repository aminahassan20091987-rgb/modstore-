# ModStore — catalogue de téléchargements par liens externes

Stack : Next.js App Router, React, TypeScript, Tailwind CSS 4, Supabase Auth/PostgreSQL, déploiement Vercel.

## Fonctionnement des fichiers

ModStore conserve uniquement les métadonnées en PostgreSQL : nom, description, type, taille indicative, URL de téléchargement, URL d'icône et URL de cover. Les fichiers APK, ZIP, ISO, APK + DATA/OBB, MP4 et MP3 ne sont pas uploadés sur Vercel ou Supabase Storage. Le bouton Télécharger ouvre/redirige vers le lien externe enregistré par l'admin. Ainsi, le stockage de fichiers de ModStore n'augmente pas avec la taille des fichiers distribués.

Les images par URL sont chargées depuis leur hébergeur externe. Il faut des URLs directes publiques, stables et autorisées. Les liens de partage qui nécessitent une connexion ou ne permettent pas le téléchargement direct peuvent ne pas fonctionner comme prévu.

## Configuration

1. Créer un projet Supabase.
2. Dans Supabase SQL Editor, exécuter `supabase/schema.sql` (sur une base existante, les instructions `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` ajoutent les champs nécessaires).
3. Dans Vercel, configurer `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` à partir du projet Supabase.
4. Déployer le dépôt avec le framework Next.js.
5. Créer un compte utilisateur via l'inscription, puis promouvoir son profil en admin depuis Supabase SQL Editor :
   `update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'TON_EMAIL');`
6. Se connecter puis ouvrir `/admin`.

## Types supportés

`apk`, `game`, `zip`, `iso`, `apk_obb`, `mp4`, `mp3`, `other`.

## Sécurité / responsabilité

- Seuls les utilisateurs dont `profiles.role = 'admin'` peuvent gérer le catalogue via l'interface.
- RLS doit rester activé.
- N'ajouter que des fichiers/liens que l'on est autorisé à distribuer. Vérifier les fichiers et liens externes avant publication.
- Les publicités sont des emplacements UI ; le réseau publicitaire doit être configuré séparément avec son compte et ses règles.
- Le compteur de téléchargements est indicatif et doit être protégé contre les abus avant une montée en charge.


## Hébergement des fichiers (sans stockage ModStore)

ModStore fonctionne comme un catalogue de liens externes : l’admin saisit l’URL directe du fichier (APK, APK + DATA/OBB, jeu, ZIP, ISO, MP4, MP3 ou autre), l’URL de l’icône et éventuellement une URL de couverture/maquette. Le site enregistre uniquement ces URL et les métadonnées dans PostgreSQL/Supabase. Les fichiers eux-mêmes ne sont pas téléversés vers Vercel ni vers Supabase Storage : le bouton Télécharger redirige le visiteur vers l’URL externe. Cela évite d’utiliser le stockage de l’application, mais dépend de la disponibilité, des permissions d’accès et des règles de l’hébergeur externe.

Pour les mises à jour de schéma d’une installation existante, exécutez les commandes `ALTER TABLE` présentes à la fin de `supabase/schema.sql`. Utilisez uniquement des liens que vous êtes autorisé à partager et, pour les images distantes, des URL HTTPS stables.
