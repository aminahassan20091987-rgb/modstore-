export function AdSlot({label='Publicité'}:{label?:string}){return <div className="ad-slot text-[10px] font-semibold uppercase tracking-[.25em]">{label}</div>}
