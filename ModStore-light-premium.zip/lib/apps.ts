import {createClient} from '@/lib/supabase/server';
import {demoApps} from '@/lib/data';
export async function getApps(){
  try { const s=await createClient(); const {data,error}=await s.from('apps').select('*').eq('status','published').order('featured',{ascending:false}).order('downloads',{ascending:false}); if(!error && data?.length) return data; } catch {}
  return demoApps;
}
export async function getAppBySlug(slug:string){
  try { const s=await createClient(); const {data,error}=await s.from('apps').select('*').eq('slug',slug).eq('status','published').maybeSingle(); if(!error && data) return data; } catch {}
  return demoApps.find(a=>a.slug===slug) ?? null;
}
