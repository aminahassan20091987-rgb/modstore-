export type FileType='apk'|'apk-data-obb'|'game'|'zip'|'iso'|'mp4'|'mp3'|'other';
export type AppRecord={id:string;slug:string;name:string;summary:string;description:string;icon_url:string|null;cover_url:string|null;file_type:FileType;category:string;version:string;size_mb:number;downloads:number;rating:number;storage_path?:string;download_url?:string;publisher:string;updated_at:string;featured?:boolean;status?:string};
export const fileTypeLabels:Record<FileType,string>={apk:'APK', 'apk-data-obb':'APK + DATA + OBB',game:'Jeu',zip:'ZIP',iso:'ISO',mp4:'MP4',mp3:'MP3',other:'Fichier'};
